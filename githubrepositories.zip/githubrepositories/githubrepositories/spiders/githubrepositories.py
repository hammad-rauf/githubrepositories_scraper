from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import GithubrepositoriesItem

import json

API_KEY = 'Add your key here'

API_URL = "http://api.scraperapi.com/?api_key=%s&url=" % API_KEY



class githuburepositoriesSpider(CrawlSpider):

    name = "githuburepositories"

    stop = 1

    url = "https://api.github.com/repositories?since=swapcode"


    def __init__(self, config_file = None, *args, **kwargs):                    
        super(githuburepositoriesSpider, self).__init__(*args, **kwargs)   

        link = open("link.txt","r")
        url = link.readline()
        url = url.strip("\n")
        link.close()

        ids = open("start.txt","r")
        idd = ids.readline()
        idd = idd.strip("\n")
        ids.close()        

        endfile = open("stop.txt","r")
        self.end = endfile.readline()
        self.end = int(self.end.strip("\n"))
        endfile.close()  

        url = url.replace("swapcode",str(idd))        

        self._url_list = url                                                              

    def start_requests(self):    
                                         
        yield Request(url = API_URL + self._url_list, callback = self.parse)

    def parse(self, response):

        products = GithubrepositoriesItem()

        json_text = response.text

        if json_text:

            json_obj = json.loads(json_text)
            
            next_page = json_obj[len(json_obj) - 1]["id"]
            next_page = int(next_page)

            products["info"] = json_obj

            code = open("start.txt","w")
            code.write(str(next_page + 1))
            code.close()

            temp_link = self.url
            temp_link = temp_link.replace("swapcode",str(next_page))

            for obj in json_obj:
                if int(obj["id"]) == self.end:
                    self.stop = 0
                    break

            if self.stop:
                yield response.follow(API_URL + temp_link,callback= self.parse)     

            yield products
 
